
export interface User {
  id: string;
  username: string;
  email: string;
  isAdmin?: boolean;
}

export interface Package {
  id: string;
  title: string;
  destination: string;
  description: string;
  price: number;
  duration: string;
  image: string;
  rating: number;
  facilities: string[];
  category: 'beach' | 'mountain' | 'city' | 'historic' | 'adventure';
}

export interface Booking {
  id: string;
  userId: string;
  packageId: string;
  date: Date;
  status: 'pending' | 'confirmed' | 'cancelled';
  paymentStatus: 'pending' | 'completed' | 'failed';
  amount: number;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
}
