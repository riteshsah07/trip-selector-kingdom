
import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import { packages } from '@/data/packages';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Search, BarChart3, Users, Package, CreditCard, FileText } from 'lucide-react';

const Admin = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Mock bookings data
  const mockBookings = [
    {
      id: 'BK-12345',
      packageId: '1',
      packageName: 'Tropical Paradise',
      customer: 'John Doe',
      date: '2023-12-15',
      amount: 1299,
      status: 'confirmed',
      paymentStatus: 'completed',
    },
    {
      id: 'BK-12346',
      packageId: '3',
      packageName: 'City Lights',
      customer: 'Jane Smith',
      date: '2023-11-20',
      amount: 1899,
      status: 'confirmed',
      paymentStatus: 'completed',
    },
    {
      id: 'BK-12347',
      packageId: '2',
      packageName: 'Alpine Adventure',
      customer: 'Mike Johnson',
      date: '2024-01-10',
      amount: 1599,
      status: 'pending',
      paymentStatus: 'pending',
    },
    {
      id: 'BK-12348',
      packageId: '5',
      packageName: 'Safari Adventure',
      customer: 'Sarah Williams',
      date: '2023-12-05',
      amount: 2299,
      status: 'confirmed',
      paymentStatus: 'completed',
    },
    {
      id: 'BK-12349',
      packageId: '4',
      packageName: 'Historic Rome',
      customer: 'David Brown',
      date: '2023-11-28',
      amount: 1499,
      status: 'cancelled',
      paymentStatus: 'refunded',
    },
  ];
  
  // Filter bookings based on search term
  const filteredBookings = searchTerm
    ? mockBookings.filter(
        booking =>
          booking.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          booking.packageName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          booking.customer.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : mockBookings;
  
  // Stats for dashboard
  const stats = [
    {
      title: 'Total Bookings',
      value: '124',
      icon: <FileText className="h-5 w-5" />,
      change: '+12%',
    },
    {
      title: 'Active Users',
      value: '85',
      icon: <Users className="h-5 w-5" />,
      change: '+5%',
    },
    {
      title: 'Revenue',
      value: '$24,825',
      icon: <CreditCard className="h-5 w-5" />,
      change: '+18%',
    },
    {
      title: 'Packages Sold',
      value: '96',
      icon: <Package className="h-5 w-5" />,
      change: '+7%',
    },
  ];
  
  // Status badge color mapping
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'refunded':
        return 'bg-blue-100 text-blue-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <div className="relative mt-4 md:mt-0">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="Search bookings..."
              className="pl-10 w-full md:w-auto"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <Tabs defaultValue="dashboard" className="space-y-8">
          <TabsList className="grid grid-cols-3 w-full md:w-auto">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
          </TabsList>
          
          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                        <h3 className="text-2xl font-bold mt-1">{stat.value}</h3>
                        <p className="text-xs text-green-600 mt-1">{stat.change} from last month</p>
                      </div>
                      <div className="rounded-full bg-blue-100 p-3 text-travel-blue">
                        {stat.icon}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {/* Recent Bookings Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Bookings</CardTitle>
                <CardDescription>Booking trends for the past 30 days</CardDescription>
              </CardHeader>
              <CardContent className="h-80 flex items-center justify-center bg-gray-50">
                <div className="flex items-center flex-col">
                  <BarChart3 className="h-16 w-16 text-gray-300 mb-4" />
                  <p className="text-gray-500">Chart visualization would go here</p>
                </div>
              </CardContent>
            </Card>
            
            {/* Popular Packages */}
            <Card>
              <CardHeader>
                <CardTitle>Popular Packages</CardTitle>
                <CardDescription>Most booked packages in the last 30 days</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {packages.slice(0, 5).map((pkg, index) => (
                    <div key={pkg.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="rounded-full bg-gray-200 w-8 h-8 flex items-center justify-center mr-4">
                          {index + 1}
                        </div>
                        <div>
                          <h4 className="font-medium">{pkg.title}</h4>
                          <p className="text-sm text-gray-500">{pkg.destination}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">${pkg.price}</p>
                        <p className="text-sm text-gray-500">
                          {Math.floor(Math.random() * 20) + 5} bookings
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="bookings">
            <Card>
              <CardHeader>
                <CardTitle>Booking Management</CardTitle>
                <CardDescription>
                  Manage all customer bookings and their status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Booking ID</TableHead>
                      <TableHead>Package</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Payment</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.map((booking) => (
                      <TableRow key={booking.id}>
                        <TableCell className="font-medium">{booking.id}</TableCell>
                        <TableCell>{booking.packageName}</TableCell>
                        <TableCell>{booking.customer}</TableCell>
                        <TableCell>{booking.date}</TableCell>
                        <TableCell>${booking.amount}</TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(booking.status)} variant="outline">
                            {booking.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={getPaymentStatusColor(booking.paymentStatus)} variant="outline">
                            {booking.paymentStatus}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {filteredBookings.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center py-8">
                          <p className="text-gray-500">No bookings found</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <CardTitle>Payment Transactions</CardTitle>
                <CardDescription>
                  Overview of all payment transactions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>Booking ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBookings.map((booking) => (
                      <TableRow key={`tx-${booking.id}`}>
                        <TableCell className="font-medium">TX-{Math.floor(10000 + Math.random() * 90000)}</TableCell>
                        <TableCell>{booking.id}</TableCell>
                        <TableCell>{booking.date}</TableCell>
                        <TableCell>${booking.amount}</TableCell>
                        <TableCell>Credit Card</TableCell>
                        <TableCell>
                          <Badge className={getPaymentStatusColor(booking.paymentStatus)} variant="outline">
                            {booking.paymentStatus}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">
                            Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    
                    {filteredBookings.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8">
                          <p className="text-gray-500">No transactions found</p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
