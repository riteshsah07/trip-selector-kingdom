
import React, { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import { getPackageById } from '@/data/packages';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Package } from '@/types';
import { format } from 'date-fns';
import { CreditCard, CircleDollarSign, Map } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const Checkout = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const packageId = searchParams.get('packageId');
  const dateParam = searchParams.get('date');
  const personsParam = searchParams.get('persons');
  
  const [packageData, setPackageData] = useState<Package | null>(null);
  const [date, setDate] = useState<Date | null>(null);
  const [persons, setPersons] = useState(2);
  const [paymentMethod, setPaymentMethod] = useState('credit-card');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const [userDetails, setUserDetails] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    country: '',
    zipCode: '',
  });
  
  const [creditCardDetails, setCreditCardDetails] = useState({
    cardNumber: '',
    cardName: '',
    expiryDate: '',
    cvv: '',
  });
  
  useEffect(() => {
    if (packageId) {
      const pkg = getPackageById(packageId);
      if (pkg) {
        setPackageData(pkg);
      } else {
        navigate('/packages');
      }
    } else {
      navigate('/packages');
    }
    
    if (dateParam) {
      try {
        setDate(new Date(dateParam));
      } catch (error) {
        console.error('Invalid date format');
      }
    }
    
    if (personsParam) {
      const parsedPersons = parseInt(personsParam);
      if (!isNaN(parsedPersons) && parsedPersons > 0) {
        setPersons(parsedPersons);
      }
    }
  }, [packageId, dateParam, personsParam, navigate]);
  
  const handleUserDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserDetails(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCreditCardChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCreditCardDetails(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!userDetails.firstName || !userDetails.lastName || !userDetails.email) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    if (paymentMethod === 'credit-card') {
      if (!creditCardDetails.cardNumber || !creditCardDetails.cardName || !creditCardDetails.expiryDate || !creditCardDetails.cvv) {
        toast({
          title: "Missing Payment Information",
          description: "Please fill in all payment details",
          variant: "destructive",
        });
        return;
      }
    }
    
    setIsProcessing(true);
    
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "Payment Successful",
        description: "Your booking has been confirmed!",
      });
      
      // Navigate to thank you page
      navigate('/thank-you');
    } catch (error) {
      toast({
        title: "Payment Failed",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
      setIsProcessing(false);
    }
  };
  
  if (!packageData || !date) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="container mx-auto p-4 flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">Loading...</h1>
          </div>
        </div>
      </div>
    );
  }
  
  const subtotal = packageData.price * persons;
  const taxes = Math.round(subtotal * 0.1);
  const total = subtotal + taxes;
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      
      <div className="container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-8 text-center">Checkout</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
              
              <div className="mb-6">
                <img 
                  src={packageData.image} 
                  alt={packageData.title} 
                  className="w-full h-40 object-cover rounded-md mb-4"
                />
                <h3 className="font-semibold text-lg">{packageData.title}</h3>
                <p className="text-gray-600">{packageData.destination}</p>
                <div className="flex items-center mt-2 text-gray-600">
                  <Map className="h-4 w-4 mr-1" />
                  <span>{packageData.duration}</span>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="flex justify-between mb-2">
                  <span>Travel Date</span>
                  <span>{format(date, 'PPP')}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span>Travelers</span>
                  <span>{persons}</span>
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="mb-4">
                <div className="flex justify-between mb-2">
                  <span>Package Price (x{persons})</span>
                  <span>${subtotal}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span>Taxes & Fees</span>
                  <span>${taxes}</span>
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>${total}</span>
              </div>
            </div>
          </div>
          
          {/* Checkout Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-6">Your Details</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input 
                    id="firstName" 
                    name="firstName" 
                    value={userDetails.firstName}
                    onChange={handleUserDetailsChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input 
                    id="lastName" 
                    name="lastName" 
                    value={userDetails.lastName}
                    onChange={handleUserDetailsChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input 
                    id="email" 
                    name="email" 
                    type="email"
                    value={userDetails.email}
                    onChange={handleUserDetailsChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input 
                    id="phone" 
                    name="phone" 
                    value={userDetails.phone}
                    onChange={handleUserDetailsChange}
                    required
                  />
                </div>
                
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Input 
                    id="address" 
                    name="address" 
                    value={userDetails.address}
                    onChange={handleUserDetailsChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input 
                    id="city" 
                    name="city" 
                    value={userDetails.city}
                    onChange={handleUserDetailsChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="country">Country</Label>
                  <Input 
                    id="country" 
                    name="country" 
                    value={userDetails.country}
                    onChange={handleUserDetailsChange}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="zipCode">Zip/Postal Code</Label>
                  <Input 
                    id="zipCode" 
                    name="zipCode" 
                    value={userDetails.zipCode}
                    onChange={handleUserDetailsChange}
                  />
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <h2 className="text-xl font-semibold mb-6">Payment Method</h2>
              
              <RadioGroup 
                value={paymentMethod} 
                onValueChange={setPaymentMethod}
                className="mb-6"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-md mb-3">
                  <RadioGroupItem value="credit-card" id="credit-card" />
                  <Label htmlFor="credit-card" className="flex items-center">
                    <CreditCard className="h-5 w-5 mr-2" />
                    Credit Card
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2 p-4 border rounded-md">
                  <RadioGroupItem value="paypal" id="paypal" />
                  <Label htmlFor="paypal" className="flex items-center">
                    <CircleDollarSign className="h-5 w-5 mr-2" />
                    PayPal
                  </Label>
                </div>
              </RadioGroup>
              
              {paymentMethod === 'credit-card' && (
                <div className="space-y-4 mb-6">
                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input 
                      id="cardNumber" 
                      name="cardNumber" 
                      placeholder="1234 5678 9012 3456"
                      value={creditCardDetails.cardNumber}
                      onChange={handleCreditCardChange}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="cardName">Name on Card</Label>
                    <Input 
                      id="cardName" 
                      name="cardName" 
                      placeholder="John Doe"
                      value={creditCardDetails.cardName}
                      onChange={handleCreditCardChange}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiryDate">Expiry Date</Label>
                      <Input 
                        id="expiryDate" 
                        name="expiryDate" 
                        placeholder="MM/YY"
                        value={creditCardDetails.expiryDate}
                        onChange={handleCreditCardChange}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="cvv">CVV</Label>
                      <Input 
                        id="cvv" 
                        name="cvv" 
                        placeholder="123"
                        value={creditCardDetails.cvv}
                        onChange={handleCreditCardChange}
                      />
                    </div>
                  </div>
                </div>
              )}
              
              <Button 
                type="submit" 
                className="w-full bg-travel-blue hover:bg-blue-600 py-6"
                disabled={isProcessing}
              >
                {isProcessing ? 'Processing Payment...' : `Complete Booking - $${total}`}
              </Button>
              
              <p className="text-sm text-gray-500 mt-4 text-center">
                By completing this booking, you agree to our Terms and Conditions and Privacy Policy.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
