
import React from 'react';
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Package } from '@/types';
import { useNavigate } from 'react-router-dom';
import { Star, Clock, MapPin } from 'lucide-react';

interface PackageCardProps {
  packageData: Package;
}

const PackageCard: React.FC<PackageCardProps> = ({ packageData }) => {
  const navigate = useNavigate();
  const { id, title, destination, description, price, duration, image, rating } = packageData;
  
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg h-full flex flex-col">
      <div className="relative h-52 overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        <div className="absolute top-2 right-2 bg-white rounded-full px-2 py-1 flex items-center shadow-md">
          <Star className="h-4 w-4 text-yellow-500 mr-1 fill-yellow-500" />
          <span className="text-sm font-semibold">{rating}</span>
        </div>
      </div>
      
      <CardContent className="p-4 flex-grow">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-semibold mb-1 text-travel-dark">{title}</h3>
          <p className="text-travel-blue font-bold">${price}</p>
        </div>
        
        <div className="flex items-center text-gray-500 mb-3">
          <MapPin className="h-4 w-4 mr-1" />
          <span className="text-sm">{destination}</span>
        </div>
        
        <div className="flex items-center text-gray-500 mb-4">
          <Clock className="h-4 w-4 mr-1" />
          <span className="text-sm">{duration}</span>
        </div>
        
        <p className="text-gray-600 line-clamp-3">{description}</p>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button 
          className="w-full bg-travel-blue hover:bg-blue-600"
          onClick={() => navigate(`/packages/${id}`)}
        >
          View Details
        </Button>
      </CardFooter>
    </Card>
  );
};

export default PackageCard;
