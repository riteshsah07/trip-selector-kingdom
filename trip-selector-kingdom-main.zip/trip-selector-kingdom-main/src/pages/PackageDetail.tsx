
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import { getPackageById } from '@/data/packages';
import { Button } from "@/components/ui/button";
import { CalendarIcon, MapPin, Clock, Star, Shield, Wifi, Coffee, CreditCard, Bath, Users } from 'lucide-react';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";

const PackageDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const packageData = getPackageById(id || '');
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [persons, setPersons] = useState(2);
  
  const facilityIcons: Record<string, React.ReactNode> = {
    "5-Star Resort": <Star className="h-5 w-5" />,
    "Private Beach": <MapPin className="h-5 w-5" />,
    "Spa": <Bath className="h-5 w-5" />,
    "Guided Tours": <Users className="h-5 w-5" />,
    "Airport Transfer": <CreditCard className="h-5 w-5" />,
    "Chalet Stay": <Home className="h-5 w-5" />,
    "Ski Equipment": <Activity className="h-5 w-5" />,
    "Cable Car Passes": <CreditCard className="h-5 w-5" />,
    "Mountain Guide": <Users className="h-5 w-5" />,
    "Hot Tub": <Bath className="h-5 w-5" />,
    "Luxury Hotel": <Star className="h-5 w-5" />,
    "Guided City Tours": <MapPin className="h-5 w-5" />,
    "Traditional Tea Ceremony": <Coffee className="h-5 w-5" />,
    "Robot Restaurant Experience": <Coffee className="h-5 w-5" />,
    "Bullet Train Pass": <CreditCard className="h-5 w-5" />,
    "Historic Hotel": <Star className="h-5 w-5" />,
    "Skip-the-Line Passes": <Shield className="h-5 w-5" />,
    "Local Guide": <Users className="h-5 w-5" />,
    "Wine Tasting": <Coffee className="h-5 w-5" />,
    "Cooking Class": <Coffee className="h-5 w-5" />,
    "Luxury Tented Camp": <Star className="h-5 w-5" />,
    "Safari Drives": <Activity className="h-5 w-5" />,
    "Maasai Village Visit": <Users className="h-5 w-5" />,
    "Hot Air Balloon Ride": <Activity className="h-5 w-5" />,
    "Local Cuisine": <Coffee className="h-5 w-5" />,
    "Luxury Cabin": <Star className="h-5 w-5" />,
    "All-Inclusive Meals": <Coffee className="h-5 w-5" />,
    "Water Sports": <Activity className="h-5 w-5" />,
    "Island Excursions": <MapPin className="h-5 w-5" />,
    "Evening Entertainment": <Music className="h-5 w-5" />,
    "Wi-Fi": <Wifi className="h-5 w-5" />,
  };
  
  // If package not found
  if (!packageData) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="container mx-auto p-4 flex-grow flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-3xl font-bold mb-4">Package Not Found</h1>
            <p className="mb-6">The package you're looking for does not exist or has been removed.</p>
            <Button 
              className="bg-travel-blue hover:bg-blue-600"
              onClick={() => navigate('/packages')}
            >
              Browse All Packages
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  const handleBook = () => {
    if (!date) {
      alert('Please select a travel date');
      return;
    }
    
    // Navigate to checkout with selected package and details
    navigate(`/checkout?packageId=${packageData.id}&date=${date.toISOString()}&persons=${persons}`);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative h-[50vh] md:h-[60vh]">
        <div 
          className="absolute inset-0 bg-center bg-cover"
          style={{ 
            backgroundImage: `url(${packageData.image})`,
            filter: "brightness(0.7)"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
          <div className="container mx-auto">
            <div className="flex items-center mb-2">
              <MapPin className="h-5 w-5 mr-2" />
              <span>{packageData.destination}</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-bold mb-2">{packageData.title}</h1>
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <Star className="h-5 w-5 text-yellow-400 fill-yellow-400 mr-1" />
                <span>{packageData.rating} rating</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-1" />
                <span>{packageData.duration}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto p-4 md:p-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Main Content */}
          <div className="flex-grow">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
                <TabsTrigger value="facilities">Facilities</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-semibold mb-4">About This Package</h2>
                    <p className="text-gray-700 leading-relaxed">
                      {packageData.description}
                      {/* Additional mock content for better UX */}
                      <br /><br />
                      Immerse yourself in the beauty and culture of {packageData.destination}. This carefully crafted package offers the perfect balance of adventure, relaxation, and cultural experiences.
                      <br /><br />
                      With expert local guides, premium accommodations, and carefully selected activities, you'll experience the very best this destination has to offer. Our 24/7 support ensures your journey is smooth and memorable from start to finish.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-semibold mb-4">What's Included</h2>
                    <ul className="space-y-3">
                      <li className="flex items-start">
                        <span className="rounded-full bg-green-100 p-1 mr-3 mt-0.5">
                          <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </span>
                        <span>Premium accommodation for the entire duration</span>
                      </li>
                      <li className="flex items-start">
                        <span className="rounded-full bg-green-100 p-1 mr-3 mt-0.5">
                          <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </span>
                        <span>Daily breakfast and select meals</span>
                      </li>
                      <li className="flex items-start">
                        <span className="rounded-full bg-green-100 p-1 mr-3 mt-0.5">
                          <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </span>
                        <span>All transportation within the destination</span>
                      </li>
                      <li className="flex items-start">
                        <span className="rounded-full bg-green-100 p-1 mr-3 mt-0.5">
                          <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </span>
                        <span>Guided tours and activities as mentioned</span>
                      </li>
                      <li className="flex items-start">
                        <span className="rounded-full bg-green-100 p-1 mr-3 mt-0.5">
                          <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </span>
                        <span>Entry fees to landmarks and attractions</span>
                      </li>
                      <li className="flex items-start">
                        <span className="rounded-full bg-green-100 p-1 mr-3 mt-0.5">
                          <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </span>
                        <span>Professional English-speaking guide</span>
                      </li>
                      <li className="flex items-start">
                        <span className="rounded-full bg-green-100 p-1 mr-3 mt-0.5">
                          <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </span>
                        <span>24/7 travel assistance and support</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="itinerary" className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-semibold mb-6">Your Detailed Itinerary</h2>
                    
                    <div className="space-y-8">
                      <div className="border-l-4 border-travel-blue pl-4 pb-2">
                        <div className="flex items-center mb-2">
                          <div className="rounded-full bg-travel-blue text-white w-8 h-8 flex items-center justify-center font-semibold mr-3">1</div>
                          <h3 className="text-xl font-medium">Day 1: Arrival & Welcome</h3>
                        </div>
                        <p className="text-gray-600 ml-11">
                          Arrive at the airport where you'll be met by our representative and transferred to your hotel. Enjoy a welcome dinner and brief orientation about your upcoming adventure.
                        </p>
                      </div>
                      
                      <div className="border-l-4 border-travel-blue pl-4 pb-2">
                        <div className="flex items-center mb-2">
                          <div className="rounded-full bg-travel-blue text-white w-8 h-8 flex items-center justify-center font-semibold mr-3">2</div>
                          <h3 className="text-xl font-medium">Day 2: Cultural Exploration</h3>
                        </div>
                        <p className="text-gray-600 ml-11">
                          After breakfast, embark on a guided tour of the main cultural attractions. Visit historical sites, local markets, and enjoy authentic cuisine for lunch.
                        </p>
                      </div>
                      
                      <div className="border-l-4 border-travel-blue pl-4 pb-2">
                        <div className="flex items-center mb-2">
                          <div className="rounded-full bg-travel-blue text-white w-8 h-8 flex items-center justify-center font-semibold mr-3">3</div>
                          <h3 className="text-xl font-medium">Day 3: Nature & Adventure</h3>
                        </div>
                        <p className="text-gray-600 ml-11">
                          Today is dedicated to natural wonders. Explore breathtaking landscapes, participate in adventurous activities, and connect with the environment.
                        </p>
                      </div>
                      
                      <div className="border-l-4 border-travel-blue pl-4 pb-2">
                        <div className="flex items-center mb-2">
                          <div className="rounded-full bg-travel-blue text-white w-8 h-8 flex items-center justify-center font-semibold mr-3">4</div>
                          <h3 className="text-xl font-medium">Day 4: Leisure & Relaxation</h3>
                        </div>
                        <p className="text-gray-600 ml-11">
                          Enjoy a day at leisure. Relax at the accommodation facilities, take optional excursions, or explore on your own. Our team is available to suggest activities.
                        </p>
                      </div>
                      
                      <div className="border-l-4 border-travel-blue pl-4 pb-2">
                        <div className="flex items-center mb-2">
                          <div className="rounded-full bg-travel-blue text-white w-8 h-8 flex items-center justify-center font-semibold mr-3">5</div>
                          <h3 className="text-xl font-medium">Day 5: Departure</h3>
                        </div>
                        <p className="text-gray-600 ml-11">
                          After a final breakfast, check out and transfer to the airport for your departure flight. End of services with fond memories to take home.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="facilities" className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-semibold mb-4">Facilities & Amenities</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {packageData.facilities.map((facility, index) => (
                        <div key={index} className="flex items-center p-3 border rounded-md">
                          <div className="mr-3 text-travel-blue">
                            {facilityIcons[facility] || <Star className="h-5 w-5" />}
                          </div>
                          <span>{facility}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="reviews" className="space-y-6">
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-semibold mb-4">Customer Reviews</h2>
                    <div className="space-y-6">
                      {/* Mock reviews */}
                      <div className="border-b pb-6">
                        <div className="flex items-center mb-2">
                          <div className="rounded-full bg-gray-200 w-10 h-10 flex items-center justify-center mr-3">
                            JD
                          </div>
                          <div>
                            <h4 className="font-medium">John Doe</h4>
                            <div className="flex items-center">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star 
                                  key={star} 
                                  className={`h-4 w-4 ${star <= 5 ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                                />
                              ))}
                              <span className="ml-2 text-sm text-gray-500">Traveled in June 2023</span>
                            </div>
                          </div>
                        </div>
                        <p className="text-gray-700">
                          "An absolutely amazing experience! The guides were knowledgeable, accommodations were top-notch, and the sights were breathtaking. Would highly recommend this package to anyone looking for an unforgettable vacation."
                        </p>
                      </div>
                      
                      <div className="border-b pb-6">
                        <div className="flex items-center mb-2">
                          <div className="rounded-full bg-gray-200 w-10 h-10 flex items-center justify-center mr-3">
                            MS
                          </div>
                          <div>
                            <h4 className="font-medium">Mary Smith</h4>
                            <div className="flex items-center">
                              {[1, 2, 3, 4].map((star) => (
                                <Star 
                                  key={star} 
                                  className={`h-4 w-4 ${star <= 4 ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                                />
                              ))}
                              <Star className="h-4 w-4 text-gray-300" />
                              <span className="ml-2 text-sm text-gray-500">Traveled in March 2023</span>
                            </div>
                          </div>
                        </div>
                        <p className="text-gray-700">
                          "Very good trip overall. The itinerary was well-planned and gave us a good mix of activities and free time. The only improvement could be in the transportation arrangements, which were occasionally delayed."
                        </p>
                      </div>
                      
                      <div>
                        <div className="flex items-center mb-2">
                          <div className="rounded-full bg-gray-200 w-10 h-10 flex items-center justify-center mr-3">
                            RJ
                          </div>
                          <div>
                            <h4 className="font-medium">Robert Johnson</h4>
                            <div className="flex items-center">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star 
                                  key={star} 
                                  className={`h-4 w-4 ${star <= 5 ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                                />
                              ))}
                              <span className="ml-2 text-sm text-gray-500">Traveled in September 2022</span>
                            </div>
                          </div>
                        </div>
                        <p className="text-gray-700">
                          "This was our third time booking with TripKingdom and they never disappoint. The service is impeccable, and they always go above and beyond to ensure a memorable experience. The accommodations were luxurious and the food was outstanding."
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Booking Sidebar */}
          <div className="lg:w-1/3">
            <div className="bg-white border rounded-lg shadow-sm p-6 sticky top-24">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-2xl font-bold">${packageData.price}</h3>
                <span className="text-sm text-gray-500">per person</span>
              </div>
              
              <div className="space-y-4 mb-6">
                <div>
                  <Label htmlFor="date" className="block mb-2">Select Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !date && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={setDate}
                        initialFocus
                        disabled={(date) => date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div>
                  <Label htmlFor="persons" className="block mb-2">Number of Travelers</Label>
                  <div className="flex border rounded-md">
                    <Button 
                      variant="ghost"
                      className="rounded-none rounded-l-md"
                      onClick={() => setPersons(Math.max(1, persons - 1))}
                      disabled={persons <= 1}
                    >
                      -
                    </Button>
                    <div className="flex-grow flex items-center justify-center">
                      {persons}
                    </div>
                    <Button 
                      variant="ghost"
                      className="rounded-none rounded-r-md"
                      onClick={() => setPersons(persons + 1)}
                    >
                      +
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-b py-4 my-4">
                <div className="flex justify-between mb-2">
                  <span>Base price x {persons} travelers</span>
                  <span>${packageData.price * persons}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span>Taxes & fees</span>
                  <span>${Math.round(packageData.price * persons * 0.1)}</span>
                </div>
              </div>
              
              <div className="flex justify-between font-bold mb-6">
                <span>Total</span>
                <span>${packageData.price * persons + Math.round(packageData.price * persons * 0.1)}</span>
              </div>
              
              <Button 
                className="w-full bg-travel-blue hover:bg-blue-600"
                onClick={handleBook}
              >
                Book Now
              </Button>
              
              <p className="text-center text-sm text-gray-500 mt-4">
                No payment required today. You'll pay when you book.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PackageDetail;
