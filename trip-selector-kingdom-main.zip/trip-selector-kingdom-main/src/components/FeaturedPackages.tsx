
import React from 'react';
import { Button } from "@/components/ui/button";
import PackageCard from './PackageCard';
import { Package } from '@/types';
import { useNavigate } from 'react-router-dom';

interface FeaturedPackagesProps {
  packages: Package[];
}

const FeaturedPackages: React.FC<FeaturedPackagesProps> = ({ packages }) => {
  const navigate = useNavigate();
  
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-travel-dark mb-4">Featured Packages</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our most popular destinations and experiences, handpicked for unforgettable adventures
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {packages.map((pkg) => (
            <PackageCard key={pkg.id} packageData={pkg} />
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button 
            className="bg-travel-blue hover:bg-blue-600 px-8"
            onClick={() => navigate('/packages')}
          >
            View All Packages
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedPackages;
