
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import Navbar from '@/components/Navbar';
import { CheckCircle } from 'lucide-react';

const ThankYou = () => {
  const navigate = useNavigate();
  
  useEffect(() => {
    // Scroll to top
    window.scrollTo(0, 0);
  }, []);
  
  // Generate a random booking reference
  const bookingReference = `TK-${Math.floor(10000 + Math.random() * 90000)}`;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="max-w-2xl w-full bg-white rounded-lg shadow-md p-8 text-center">
          <div className="mb-6">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
          </div>
          
          <h1 className="text-3xl font-bold mb-4 text-gray-800">Booking Confirmed!</h1>
          
          <p className="text-lg text-gray-600 mb-6">
            Thank you for booking with TripKingdom. Your adventure is confirmed and we're excited to help you create unforgettable memories.
          </p>
          
          <div className="bg-gray-50 p-6 rounded-lg mb-6">
            <h2 className="text-xl font-semibold mb-4">Booking Details</h2>
            <div className="flex justify-between mb-2">
              <span className="font-medium">Booking Reference:</span>
              <span>{bookingReference}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="font-medium">Status:</span>
              <span className="text-green-600">Confirmed</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Payment Status:</span>
              <span className="text-green-600">Paid</span>
            </div>
          </div>
          
          <p className="text-gray-600 mb-8">
            We've sent a confirmation email with all the details of your booking. 
            If you have any questions, please contact our customer service.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              className="bg-travel-blue hover:bg-blue-600"
              onClick={() => navigate('/')}
            >
              Return to Home
            </Button>
            
            <Button 
              variant="outline"
              onClick={() => window.print()}
            >
              Print Confirmation
            </Button>
          </div>
        </div>
      </div>
      
      {/* Call to Action */}
      <div className="bg-gray-50 py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-4">What's Next?</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Prepare for your journey! Check out our travel tips and destination guides to make the most of your trip.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              variant="outline"
              onClick={() => navigate('/packages')}
            >
              Explore More Packages
            </Button>
            
            <Button 
              variant="ghost"
              onClick={() => navigate('/contact')}
            >
              Contact Support
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ThankYou;
