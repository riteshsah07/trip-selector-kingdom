
import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import PackageCard from '@/components/PackageCard';
import { packages } from '@/data/packages';
import { Package } from '@/types';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Search, SlidersHorizontal } from 'lucide-react';

const Packages = () => {
  const [filteredPackages, setFilteredPackages] = useState<Package[]>(packages);
  const [searchTerm, setSearchTerm] = useState('');
  const [priceRange, setPriceRange] = useState([0, 5000]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  
  const categories = [
    { id: 'beach', label: 'Beach' },
    { id: 'mountain', label: 'Mountain' },
    { id: 'city', label: 'City' },
    { id: 'historic', label: 'Historic' },
    { id: 'adventure', label: 'Adventure' },
  ];
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    applyFilters(e.target.value, priceRange, selectedCategories);
  };
  
  const handlePriceChange = (value: number[]) => {
    setPriceRange(value);
    applyFilters(searchTerm, value, selectedCategories);
  };
  
  const handleCategoryChange = (category: string, checked: boolean) => {
    let newCategories: string[];
    
    if (checked) {
      newCategories = [...selectedCategories, category];
    } else {
      newCategories = selectedCategories.filter(c => c !== category);
    }
    
    setSelectedCategories(newCategories);
    applyFilters(searchTerm, priceRange, newCategories);
  };
  
  const applyFilters = (search: string, price: number[], categories: string[]) => {
    let filtered = packages;
    
    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(
        pkg => 
          pkg.title.toLowerCase().includes(searchLower) || 
          pkg.destination.toLowerCase().includes(searchLower) ||
          pkg.description.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply price filter
    filtered = filtered.filter(pkg => pkg.price >= price[0] && pkg.price <= price[1]);
    
    // Apply category filter
    if (categories.length > 0) {
      filtered = filtered.filter(pkg => categories.includes(pkg.category));
    }
    
    setFilteredPackages(filtered);
  };
  
  const resetFilters = () => {
    setSearchTerm('');
    setPriceRange([0, 5000]);
    setSelectedCategories([]);
    setFilteredPackages(packages);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Header */}
      <header className="bg-travel-blue py-16 px-4">
        <div className="container mx-auto text-center text-white">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Explore Our Travel Packages</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Discover amazing destinations and start planning your next unforgettable adventure
          </p>
        </div>
      </header>
      
      <div className="container mx-auto px-4 py-8">
        {/* Search bar */}
        <div className="relative mb-8">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            type="text"
            placeholder="Search destinations, experiences..."
            className="pl-10"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
        
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-travel-dark">
            {filteredPackages.length} {filteredPackages.length === 1 ? 'Package' : 'Packages'} Available
          </h2>
          <Button 
            variant="outline"
            className="flex items-center gap-2"
            onClick={() => setShowFilters(!showFilters)}
          >
            <SlidersHorizontal size={18} />
            {showFilters ? 'Hide Filters' : 'Show Filters'}
          </Button>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters */}
          {showFilters && (
            <div className="w-full md:w-64 bg-gray-50 p-6 rounded-lg h-fit">
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-4">Price Range</h3>
                <div className="px-2">
                  <Slider
                    defaultValue={priceRange}
                    min={0}
                    max={5000}
                    step={100}
                    value={priceRange}
                    onValueChange={handlePriceChange}
                  />
                  <div className="flex justify-between mt-2 text-sm text-gray-600">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}</span>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-4">Categories</h3>
                <div className="space-y-2">
                  {categories.map(category => (
                    <div key={category.id} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`category-${category.id}`}
                        checked={selectedCategories.includes(category.id)}
                        onCheckedChange={(checked) => 
                          handleCategoryChange(category.id, checked as boolean)
                        }
                      />
                      <Label 
                        htmlFor={`category-${category.id}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {category.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={resetFilters}
              >
                Reset Filters
              </Button>
            </div>
          )}
          
          {/* Packages Grid */}
          <div className="flex-1">
            {filteredPackages.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPackages.map((pkg) => (
                  <PackageCard key={pkg.id} packageData={pkg} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-gray-50 rounded-lg">
                <h3 className="text-lg font-semibold mb-2">No packages found</h3>
                <p className="text-gray-600 mb-4">Try adjusting your search or filters</p>
                <Button onClick={resetFilters}>Reset Filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Packages;
