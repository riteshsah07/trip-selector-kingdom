
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Menu, X, User } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();
  
  // Mock authentication state - in a real app you'd use context/state management
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const handleLogout = () => {
    setIsLoggedIn(false);
    navigate('/');
  };

  return (
    <nav className="bg-white shadow-md py-4 relative z-10">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <span className="text-2xl font-bold text-travel-blue">TripKingdom</span>
        </Link>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-6">
          <Link to="/" className="text-gray-700 hover:text-travel-blue transition-colors">Home</Link>
          <Link to="/packages" className="text-gray-700 hover:text-travel-blue transition-colors">Packages</Link>
          <Link to="/about" className="text-gray-700 hover:text-travel-blue transition-colors">About</Link>
          <Link to="/contact" className="text-gray-700 hover:text-travel-blue transition-colors">Contact</Link>
          
          {isLoggedIn ? (
            <div className="flex items-center space-x-4">
              <Link to="/profile" className="flex items-center text-gray-700 hover:text-travel-blue">
                <User size={20} className="mr-1" />
                Profile
              </Link>
              <Button 
                variant="ghost" 
                onClick={handleLogout}
                className="text-gray-700 hover:text-travel-blue"
              >
                Logout
              </Button>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <Link to="/login">
                <Button variant="outline">Login</Button>
              </Link>
              <Link to="/register">
                <Button className="bg-travel-blue hover:bg-blue-600">Register</Button>
              </Link>
            </div>
          )}
        </div>
        
        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <Button variant="ghost" onClick={toggleMenu} size="icon">
            {isMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white absolute top-16 left-0 right-0 z-20 shadow-md animate-fade-in">
          <div className="flex flex-col p-4 space-y-3">
            <Link to="/" className="text-gray-700 hover:text-travel-blue py-2" onClick={toggleMenu}>Home</Link>
            <Link to="/packages" className="text-gray-700 hover:text-travel-blue py-2" onClick={toggleMenu}>Packages</Link>
            <Link to="/about" className="text-gray-700 hover:text-travel-blue py-2" onClick={toggleMenu}>About</Link>
            <Link to="/contact" className="text-gray-700 hover:text-travel-blue py-2" onClick={toggleMenu}>Contact</Link>
            
            {isLoggedIn ? (
              <>
                <Link to="/profile" className="text-gray-700 hover:text-travel-blue py-2" onClick={toggleMenu}>Profile</Link>
                <Button 
                  variant="ghost" 
                  onClick={() => {
                    handleLogout();
                    toggleMenu();
                  }}
                  className="justify-start text-gray-700 hover:text-travel-blue py-2"
                >
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={toggleMenu}>
                  <Button variant="outline" className="w-full">Login</Button>
                </Link>
                <Link to="/register" onClick={toggleMenu}>
                  <Button className="w-full bg-travel-blue hover:bg-blue-600">Register</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
