
import { Package } from '../types';

export const packages: Package[] = [
  {
    id: '1',
    title: 'Tropical Paradise',
    destination: 'Bali, Indonesia',
    description: 'Experience the serene beaches and vibrant culture of Bali. Enjoy luxury accommodations, guided tours to ancient temples, and authentic local cuisine.',
    price: 1299,
    duration: '7 days',
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    facilities: ['5-Star Resort', 'Private Beach', 'Spa', 'Guided Tours', 'Airport Transfer'],
    category: 'beach'
  },
  {
    id: '2',
    title: 'Alpine Adventure',
    destination: 'Swiss Alps, Switzerland',
    description: 'Discover the breathtaking mountain landscapes of the Swiss Alps. Ski on pristine slopes, enjoy Swiss chocolate, and relax in mountain chalets.',
    price: 1599,
    duration: '8 days',
    image: 'https://images.unsplash.com/photo-1531310197839-ccf54634509e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    facilities: ['Chalet Stay', 'Ski Equipment', 'Cable Car Passes', 'Mountain Guide', 'Hot Tub'],
    category: 'mountain'
  },
  {
    id: '3',
    title: 'City Lights',
    destination: 'Tokyo, Japan',
    description: 'Immerse yourself in the futuristic cityscape and traditional culture of Tokyo. Experience the blend of ancient temples and modern skyscrapers.',
    price: 1899,
    duration: '10 days',
    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    facilities: ['Luxury Hotel', 'Guided City Tours', 'Traditional Tea Ceremony', 'Robot Restaurant Experience', 'Bullet Train Pass'],
    category: 'city'
  },
  {
    id: '4',
    title: 'Historic Rome',
    destination: 'Rome, Italy',
    description: 'Walk through the ancient streets of Rome and discover 3000 years of history. Visit the Colosseum, Vatican City, and enjoy authentic Italian cuisine.',
    price: 1499,
    duration: '6 days',
    image: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    rating: 4.6,
    facilities: ['Historic Hotel', 'Skip-the-Line Passes', 'Local Guide', 'Wine Tasting', 'Cooking Class'],
    category: 'historic'
  },
  {
    id: '5',
    title: 'Safari Adventure',
    destination: 'Serengeti, Tanzania',
    description: 'Witness the majestic wildlife of Africa in their natural habitat. Experience the thrill of safari drives and relax in luxury tented camps.',
    price: 2299,
    duration: '9 days',
    image: 'https://images.unsplash.com/photo-1523805009345-7448845a9e53?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    facilities: ['Luxury Tented Camp', 'Safari Drives', 'Maasai Village Visit', 'Hot Air Balloon Ride', 'Local Cuisine'],
    category: 'adventure'
  },
  {
    id: '6',
    title: 'Caribbean Cruise',
    destination: 'Caribbean Islands',
    description: 'Sail through the crystal-clear waters of the Caribbean. Visit multiple islands, enjoy water sports, and relax on pristine beaches.',
    price: 1799,
    duration: '8 days',
    image: 'https://images.unsplash.com/photo-1500514966906-fe367a725e2f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    rating: 4.5,
    facilities: ['Luxury Cabin', 'All-Inclusive Meals', 'Water Sports', 'Island Excursions', 'Evening Entertainment'],
    category: 'beach'
  }
];

export const getFeaturedPackages = (): Package[] => {
  return packages.slice(0, 3);
};

export const getPackageById = (id: string): Package | undefined => {
  return packages.find(pkg => pkg.id === id);
};
